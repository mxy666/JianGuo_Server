define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-10-21T04:22:34.557Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
